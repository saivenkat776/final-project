package Service;

import Bean.AgentAccountCreationBean;
import Dao.AgentAccountCreationDao;

public class AgentAccountCreationService {

	public static long addAccountService(String name, String street, String city, String state, int zip,
			String business, String uname, String agentname) {
		// TODO Auto-generated method stub
		AgentAccountCreationDao AccountDao = new AgentAccountCreationDao();
		AgentAccountCreationBean accbean = new AgentAccountCreationBean();
		accbean.setName(name);
		accbean.setStreet(street);
		accbean.setCity(city);
		accbean.setState(state);
		accbean.setZip(zip);
		accbean.setBusiness(business);
		accbean.setUname(uname);
        accbean.setAgentname(agentname);
		long Accseq = 0;
		 try
		 {
			 Accseq = AccountDao.addAccount(accbean);
			 return Accseq;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return Accseq;
		 }
		
	
	}

}
