package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Service.AgentAccountCreationService;

public class AgentAccountCreationController extends HttpServlet{
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd = null;
		String name="";
		String street="";
		String city="";
		String state="";
		int zip=0;
		String business="";
		String uname="";
		String agentname="";
		agentname=request.getParameter("agentname");
		name=request.getParameter("insured");
		street=request.getParameter("street");
		city=request.getParameter("city");
		state=request.getParameter("state");
		
		String pin=request.getParameter("pincode");
		zip=Integer.parseInt(pin);
		
		business=request.getParameter("business");
		uname=request.getParameter("uname");
		
		System.out.println(agentname);
		
		long Accseq = AgentAccountCreationService.addAccountService(name, street, city,state,zip,business,uname,agentname);
		out.print("Account Number is"+Accseq);
		out.println("<br><br><a href='Login.jsp'>Log out</a>");

			}
}
