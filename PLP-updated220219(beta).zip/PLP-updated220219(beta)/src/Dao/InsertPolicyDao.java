package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class InsertPolicyDao {
	Connection con=null;
	ResultSet resultSet = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt1 = null;
	 int k=0;
	 String pol_id;
	public int Inspol(int policynumber, HashMap<String, String> ans) {
		for(Map.Entry<String,String> m:ans.entrySet())
		{
			if(m.getValue() !=null) {
		try {
			con=DB.getConnection();
			String val=m.getValue();
			String Que=m.getKey();
			String sql="select pol_ques_id from policy_questions where POL_QUES_DESC='"+Que+"'";
			pstmt1 = con.prepareStatement(sql);
			resultSet=pstmt1.executeQuery();
			while(resultSet.next()) {
				pol_id=resultSet.getString(1);
			}
			System.out.println(policynumber+" "+pol_id+" "+m.getValue());
			String ins_str ="insert into  policy_details values("+policynumber+",'"+pol_id+"','"+val+"')";
			pstmt = con.prepareStatement(ins_str);
			   k=pstmt.executeUpdate();
			 
		
	}catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
			}
		}
		  return k;

}
}
